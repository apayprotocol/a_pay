=== A-Pay Web3 AI Paywall ===
Contributors: apay98
Tags: ai-paywall, web3, monetization, gptbot, micropayments
Requires at least: 5.8
Tested up to: 7.2
Requires PHP: 7.4
Stable tag: 0.1.10
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Universal HTTP 402 Web3 AI paywall for WordPress. Monetize GPTBot, ClaudeBot, and AI crawlers on Base L2 while humans browse 100% free.

== Description ==

**A-Pay Web3 AI Paywall** is an HTTP 402 Web3 micropayment gatekeeper for WordPress & WooCommerce that allows website owners to monetize autonomous AI crawlers, scrapers, and LLM bots (OpenAI GPTBot, Anthropic ClaudeBot, PerplexityBot, ByteSpider, and Meta-ExternalAgent) on Base Layer 2.

### 🌟 Key Features

* **100% Free for Real Humans**: Human visitors on desktop and mobile web browsers (Chrome, Safari, Firefox, Edge) browse your site completely free without any paywalls, popups, or captchas.
* **SEO Protected**: Googlebot, Bingbot, DuckDuckBot, and other search engines are automatically whitelisted so your search rankings and indexing remain completely intact.
* **HTTP 402 Web3 Challenge Gate**: Autonomous AI crawlers are presented with a cryptographic HTTP 402 Payment Required challenge specifying Base Layer 2 settlement details under EIP-712 standards.
* **Voucher & Nonce Verification**: Validates incoming Authorization headers, strictly checks payment amounts against required pricing, verifies EVM address formats, and enforces single-use session nonces to prevent replay attacks.
* **Dual Settlement Rails**: Accept USDC (Circle native) or $APAY protocol tokens on Base Mainnet (Chain ID 8453) or Base Sepolia Testnet (Chain ID 84532).
* **Instant WordPress Setup**: Zero complex coding required. Simply install, activate, paste your Base wallet address, and your content is protected immediately.

== 3rd Party Service Disclosure ==

This plugin interacts with external decentralized infrastructure and protocols to facilitate autonomous payments:

1. **A-Pay Protocol Portal & Telemetry (`https://apayprotocol.org`)**:
   * **Purpose**: Provides developer protocol documentation, health probes, token contract verification, and EIP-712 scheme metadata.
   * **Terms of Service**: https://apayprotocol.org
   * **Privacy Policy**: https://apayprotocol.org

2. **Base Layer 2 Decentralized Network (`https://mainnet.base.org` / `https://sepolia.base.org`)**:
   * **Purpose**: Used for on-chain cryptographic transaction verification and router contract settlement (`0x71434344beEF9C44fF3BC95572bEB7bFB8847ec6`).
   * **Terms of Service**: https://base.org

== Installation ==

1. Upload the `apay-web3-ai-paywall` folder to the `/wp-content/plugins/` directory, or install the plugin directly through the WordPress plugins screen.
2. Activate the plugin through the **Plugins** screen in WordPress.
3. Navigate to **Settings -> A-Pay Web3 AI Paywall**.
4. Enter your Base L2 EVM wallet address to receive payments.
5. Choose your pricing (default: $0.001 USDC / 4.0 $APAY) and save changes.

== Frequently Asked Questions ==

= Will this plugin block my regular website visitors? =
No. Regular human visitors browsing with desktop or mobile browsers are completely whitelisted and will never see paywalls, captchas, or payment prompts.

= Will this affect my Google Search SEO ranking? =
No. Googlebot, Bingbot, DuckDuckBot, and verified search engine crawlers are automatically whitelisted so your SEO rankings and search previews remain unaffected.

= Which AI bots are challenged with HTTP 402? =
By default, the plugin identifies: `gptbot`, `chatgpt-user`, `claudebot`, `claude-web`, `anthropic-ai`, `perplexitybot`, `bytespider`, `ccbot`, `google-extended`, `cohere-ai`, `diffbot`, `facebookbot`, `omgilibot`, `applebot-extended`, `meta-externalagent`, `amazonbot`, `timpibot`, and `youbot`. You can also add custom bot user-agents in Settings.

= Do I need a credit card or bank account? =
No. Micropayments settle directly to your non-custodial EVM wallet address on Base L2.

= Can I sell digital products or use this with WooCommerce? =
Yes! You can use the [apay_button amount="10" title="My eBook"] shortcode on any post or page, or activate the official A-Pay WooCommerce Payment Gateway for full shopping cart checkouts.

== Screenshots ==

1. A-Pay Web3 AI Paywall Settings screen in WordPress Admin.
2. Live HTTP 402 Machine-to-Machine payment challenge received by automated AI bots.

== Changelog ==

= 0.1.10 =
* Confirmed compatibility with WordPress 7.2 and PHP 8.6.
* Replaced all inline script tags with WordPress-native wp_enqueue_script and wp_add_inline_script loading for full Plugin Check compliance.
* Hardened WooCommerce AJAX order completion with WordPress nonce verification and strict EVM tx hash / address validation.
* Fixed X-APay-Test probe behavior so probe headers never bypass server-issued payment voucher nonce verification.
* Switched JSON and URL helpers to wp_json_encode and wp_parse_url, fixed 18-decimal $APAY integer formatting, and added CORS expose headers.

= 0.1.9 =
* Added Zero-Config Auto Domain Escrow for unconfigured domains (auto-claimable via /.well-known/apay-claim.txt).
* Added WooCommerce 1-Click Web3 Refund Engine in WordPress admin order metabox.
* Full High-Performance Order Storage (HPOS) declaration and compatibility for WooCommerce.
* Verified Base L2 Router & Escrow contract integrations.

= 0.1.8 =
* Added universal [apay_button] shortcode for 1-click digital product sales on any post or page.
* Added official WooCommerce Payment Gateway (WC_Gateway_APay) with instant Web3 modal checkout.
* Renamed plugin display name and slug to A-Pay Web3 AI Paywall.
* Strictly sanitize and unslash all HTTP request headers and authorization inputs.
* Added server-side nonce issuing and single-use validation to prevent voucher replay.
* Added minimum payment amount validation against required pricing.
* Removed duplicate Tested up to header from main PHP file.
* Limited tags to 5 directory-compliant tags and short description to 135 characters.
